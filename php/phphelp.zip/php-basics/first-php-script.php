<!DOCTYPE html>
<html>
<head>

	<title>Using Echo</title>

</head>
<body>

  <p>This is standard HTML</p>
	
  <?php
  echo 'This was generated using PHP!';
  //echo used to print 
  //print the text above
  ?>
	
	<!-- 
	•	To load a php web page you must open it through the web server – type the address into the web browser address bar.
•	PHP web pages use a .php file extension not .html
•	Use whitespace and comments to make your code easier to read and manage – especially for coursework code.
•	Comments in HTML and PHP use different notation, make sure you use the correct method when commenting code.
•	Don’t forget to end every PHP statement with a semi-colon (;).

  -->
	
</body>
</html>
